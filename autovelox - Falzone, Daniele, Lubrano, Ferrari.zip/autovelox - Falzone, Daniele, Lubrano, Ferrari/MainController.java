package autovelox;
import java.io.*;
import java.util.*;
public class MainController {

	public static void main(String[] args) throws Exception{
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader t = new BufferedReader(in);
			String st;
			char sc;
			ArrayAutovelox v=new ArrayAutovelox();
			FileAutovelox f=new FileAutovelox();
			do{
			System.out.print("\nScegli: ");
			sc=t.readLine().charAt(0);
			switch(sc){
			case 'a':
			case 'A':
				System.out.print("\nInserisci un comune italiano: ");
				st=t.readLine();
				v=f.cerca(st);				
				if(v==null)
					System.out.print("\nOutput nullo.");
				else
					v.stampa();
				break;
			case 'u':
			case 'U':
				System.out.print("\nProgramma terminato.");
				break;
			default: System.out.print("\nScelta errata.");
			}
			
			}while(sc!='u'&&sc!='U');
		}

	
		

	}


