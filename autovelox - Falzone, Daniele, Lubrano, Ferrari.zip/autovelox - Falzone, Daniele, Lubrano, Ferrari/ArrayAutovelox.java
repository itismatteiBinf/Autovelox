package autovelox;

import java.util.ArrayList;

public class ArrayAutovelox{
	
	private ArrayList<Autovelox>ar;
	
	public ArrayAutovelox(){
		ar = new ArrayList<Autovelox>();
	}
	public void add(Autovelox a){
		ar.add(a);
	}
	public int size(){
		return ar.size();
	}
	public void stampa(){
		System.out.print("\nElenco AUTOVELOX: ");
		for(int i=0;i<ar.size();i++)
			System.out.print("\n"+ar.get(i));
	}
}
