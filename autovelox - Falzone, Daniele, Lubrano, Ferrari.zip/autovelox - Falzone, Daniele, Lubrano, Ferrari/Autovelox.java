package autovelox;


public class Autovelox {
	
	private String  lon, provincia, comune, nome, lat, regione;
	
	//leggere solo: longitudine, provincia, comune, latitudine, regione 
	public Autovelox(String lon, String provincia, String comune, String nome, String lat, String regione){
		this.lon=lon;
		this.provincia=provincia;
		this.comune=comune;
		this.nome=nome;
		this.lat=lat;
		this.regione=regione;
		
	}
	
	public Autovelox (){
		this.lon=this.provincia=this.comune=this.lat=this.regione= null;
	}
	
	//metodi set
	public void setLon (String lon){
		this.lon=lon;
	}
	
	public void setProvincia (String provincia){
		this.provincia=provincia;
	}
	
	public void setComune(String comune){
		this.comune=comune;
	}
	
	public void setNome(String nome){
		this.nome=nome;
	}
	
	public void setLat(String lat){
		this.lat=lat;
	}
	
	public void setRegione(String regione){
		this.regione=regione;
	}
	
	//metodi get
	
	public String getLon(){
		return lon;
	}
	
	public String getProvincia(){
		return provincia;
	}
	
	public String getComune(){
		return comune;
	}
	
	public String getNome(){
		return nome;
	}
	public String getLat(){
		return lat;
	}
	
	public String setRegione(){
		return regione;
	}
	
	//metodo toString
	
	public String toString(){
		return comune+", "+provincia+", "+regione+", LONGITUDINE="+lon+", LATITUDINE="+lat;
	}
	
	

}
