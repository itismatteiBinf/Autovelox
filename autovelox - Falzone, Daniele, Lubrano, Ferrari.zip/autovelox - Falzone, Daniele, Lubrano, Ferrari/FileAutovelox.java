package autovelox;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;
import java.io.*;

public class FileAutovelox {
	
	private Autovelox auto;

	
	public ArrayAutovelox cerca(String x){		
		//char CR  = (char) 0x0D, LF  = (char) 0x0A;		
		String st="", lon, provincia, comune, nome, lat, regione;
		//String fine="";
		//fine+=CR+LF;
		int n, c=1;
		ArrayAutovelox ar=new ArrayAutovelox();
		try{
			File f=new File("autovelox.csv");
		Scanner s = new Scanner (f);
		s.useDelimiter(";");
		s.useLocale(new Locale("US"));
		s.nextLine();
		while(s.hasNext() && c<1525){
			if(st.equals("")){
				n=1;
			}
			else
				n=3; //0=CR, 1=LF, 2="
			
		st=s.next();				
		lon= st;
		lon=lon.substring(n, lon.length()-1);
		provincia = s.next();
		provincia=provincia.substring(1, provincia.length()-1);
		comune = s.next();
		comune=comune.substring(1, comune.length()-1);
		s.next();
		s.next();
		nome = s.next();
		nome=nome.substring(1, nome.length()-1);
		lat = s.next();
		lat=lat.substring(1, lat.length()-1);
		s.next();
		s.next();
		regione = s.next();
		regione=regione.substring(1, regione.length()-1);
		if(x.equalsIgnoreCase(comune)){
		auto= new Autovelox(lon, provincia, comune, nome, lat, regione);
		ar.add(auto);
		}
		c++;
		}
		s.close();
		}
		catch(IOException e){
			System.out.print("\n"+e);
		}
		if(ar.size()==0)
			return null;
		return ar;
	}

}
